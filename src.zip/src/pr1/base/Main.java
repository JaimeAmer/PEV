package pr1.base;

import pr1.iu.Application;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Application();
	}

}

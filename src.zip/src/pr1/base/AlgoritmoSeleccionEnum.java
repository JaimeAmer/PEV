package pr1.base;

public class AlgoritmoSeleccionEnum {
	
	private TipoAlgoritmo tipo;
	
	public String toString(){
		return tipo.toString(tipo);
	}
	
}

